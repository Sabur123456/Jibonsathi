package com.jibonsathi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF175943)
private val DeepForest = Color(0xFF103D32)
private val Cream = Color(0xFFF7F5EF)
private val Gold = Color(0xFFE9D5A3)

data class MatchProfile(
    val id: Int,
    val name: String,
    val gender: String,
    val age: Int,
    val country: String,
    val city: String,
    val education: String,
    val profession: String,
    val emoji: String,
    val intro: String
)

private val sampleProfiles = listOf(
    MatchProfile(1, "আয়েশা রহমান", "পাত্রী", 24, "বাংলাদেশ", "ঢাকা", "স্নাতক", "শিক্ষকতা", "👩🏻", "পারিবারিক মূল্যবোধ ও পারস্পরিক সম্মানকে গুরুত্ব দেন।"),
    MatchProfile(2, "মোহাম্মদ হাসান", "পাত্র", 28, "সৌদি আরব", "রিয়াদ", "স্নাতকোত্তর", "প্রকৌশলী", "👨🏻", "দায়িত্বশীল ও সুন্দর পারিবারিক জীবন গড়তে আগ্রহী।"),
    MatchProfile(3, "ফাতিমা আক্তার", "পাত্রী", 26, "সৌদি আরব", "জেদ্দা", "স্নাতকোত্তর", "স্বাস্থ্যসেবা", "👩🏽", "পারস্পরিক বোঝাপড়া ও সম্মতিকে গুরুত্ব দেন।"),
    MatchProfile(4, "আব্দুল্লাহ করিম", "পাত্র", 30, "বাংলাদেশ", "চট্টগ্রাম", "স্নাতক", "ব্যবসা", "👨🏽", "সততা ও পারিবারিক মূল্যবোধে বিশ্বাসী।"),
    MatchProfile(5, "মারিয়াম ইসলাম", "পাত্রী", 22, "ভারত", "কলকাতা", "অন্যান্য", "শিক্ষার্থী", "👩🏻‍🦱", "পরিবারের সম্মতিতে বিয়ে করতে আগ্রহী।"),
    MatchProfile(6, "ইউসুফ আহমেদ", "পাত্র", 27, "সৌদি আরব", "মদিনা", "স্নাতকোত্তর", "আইটি পেশাজীবী", "👨🏾", "সততা, সম্মান ও সহযোগিতায় বিশ্বাসী।")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JibonSathiApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JibonSathiApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var genderFilter by remember { mutableStateOf("সব প্রোফাইল") }
    var countryFilter by remember { mutableStateOf("সব দেশ") }
    var savedIds by remember { mutableStateOf(setOf<Int>()) }
    var searchText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    val filtered = sampleProfiles.filter { profile ->
        (genderFilter == "সব প্রোফাইল" || profile.gender == genderFilter) &&
        (countryFilter == "সব দেশ" || profile.country == countryFilter) &&
        (searchText.isBlank() || profile.name.contains(searchText, ignoreCase = true) ||
                profile.city.contains(searchText, ignoreCase = true))
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Forest,
            onPrimary = Color.White,
            secondary = Gold,
            background = Cream,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("☾ জীবনসাথী", fontWeight = FontWeight.Bold, color = Color.White)
                            Text("মুসলিম ম্যারেজ ম্যাচিং", fontSize = 11.sp, color = Color(0xFFD6E9DD))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepForest)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Search, contentDescription = "খুঁজুন") },
                        label = { Text("খুঁজুন") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Favorite, contentDescription = "পছন্দ") },
                        label = { Text("পছন্দ") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Stars, contentDescription = "প্রিমিয়াম") },
                        label = { Text("প্রিমিয়াম") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.Person, contentDescription = "প্রোফাইল") },
                        label = { Text("প্রোফাইল") }
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DeepForest, RoundedCornerShape(18.dp))
                                .padding(18.dp)
                        ) {
                            Text("হালাল পথে খুঁজুন", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text("জীবনের সঙ্গী", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text("বিশ্বাস, মূল্যবোধ ও পারিবারিক সম্মতিতে নতুন জীবনের শুরু।", color = Color(0xFFE0EEE6))
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("আপনার জন্য প্রোফাইল", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = searchText,
                            onValueChange = { searchText = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("নাম বা শহর দিয়ে খুঁজুন") },
                            singleLine = true
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterDropdown(
                                label = "লিঙ্গ",
                                selected = genderFilter,
                                options = listOf("সব প্রোফাইল", "পাত্র", "পাত্রী"),
                                modifier = Modifier.weight(1f),
                                onSelect = { genderFilter = it }
                            )
                            FilterDropdown(
                                label = "দেশ",
                                selected = countryFilter,
                                options = listOf("সব দেশ", "বাংলাদেশ", "সৌদি আরব", "ভারত"),
                                modifier = Modifier.weight(1f),
                                onSelect = { countryFilter = it }
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("${filtered.size}টি নমুনা প্রোফাইল", color = Color.Gray, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            modifier = Modifier.fillMaxWidth().height(if (filtered.isEmpty()) 100.dp else ((filtered.size + 1) / 2 * 270).dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            userScrollEnabled = false
                        ) {
                            items(filtered, key = { it.id }) { profile ->
                                ProfileCard(
                                    profile = profile,
                                    isSaved = profile.id in savedIds,
                                    onSave = {
                                        savedIds = if (profile.id in savedIds) savedIds - profile.id else savedIds + profile.id
                                    },
                                    onInterest = { message = "ডেমো অনুরোধ: ${profile.name}। বাস্তব সংস্করণে লগইন ও সম্মতি যাচাই দরকার।" }
                                )
                            }
                        }
                    }
                    1 -> {
                        Text("পছন্দের তালিকা ♥", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        val saved = sampleProfiles.filter { it.id in savedIds }
                        if (saved.isEmpty()) {
                            Text("এখনো কোনো প্রোফাইল সংরক্ষণ করা হয়নি।", color = Color.Gray)
                        } else {
                            saved.forEach { profile ->
                                ProfileCard(
                                    profile = profile,
                                    isSaved = true,
                                    onSave = { savedIds = savedIds - profile.id },
                                    onInterest = { message = "ডেমো অনুরোধ: ${profile.name}" }
                                )
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                    2 -> PremiumScreen(onInfo = { message = it })
                    3 -> ProfileForm(onPreview = { message = it })
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "ডেমো সংস্করণ · নমুনা প্রোফাইল · বাস্তব সদস্য নয়",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }

        if (message != null) {
            AlertDialog(
                onDismissRequest = { message = null },
                title = { Text("জীবনসাথী") },
                text = { Text(message.orEmpty()) },
                confirmButton = {
                    TextButton(onClick = { message = null }) { Text("ঠিক আছে") }
                }
            )
        }
    }
}

@Composable
private fun FilterDropdown(
    label: String,
    selected: String,
    options: List<String>,
    modifier: Modifier = Modifier,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected, maxLines = 1, fontSize = 12.sp)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = { onSelect(option); expanded = false }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfileCard(
    profile: MatchProfile,
    isSaved: Boolean,
    onSave: () -> Unit,
    onInterest: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(10.dp)) {
            Box(
                Modifier.fillMaxWidth().height(82.dp)
                    .background(Color(0xFFE6EDE3), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(profile.emoji, fontSize = 39.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(profile.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
            Text("${profile.age} বছর · ${profile.city}", color = Color.Gray, fontSize = 11.sp)
            Text("${profile.country} · ${profile.education}", color = Color.Gray, fontSize = 10.sp)
            Text(profile.profession, color = Forest, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 3.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (isSaved) Color(0xFFB7DCC4) else Forest)
            ) {
                Text(if (isSaved) "♥ সংরক্ষিত" else "♡ পছন্দ", fontSize = 11.sp,
                    color = if (isSaved) DeepForest else Color.White)
            }
            OutlinedButton(
                onClick = onInterest,
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 2.dp)
            ) { Text("আগ্রহ প্রকাশ", fontSize = 10.sp) }
        }
    }
}

@Composable
private fun PremiumScreen(onInfo: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("সদস্যপদ বেছে নিন", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("ফ্রি প্ল্যান", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("৳০ · বিনামূল্যে", color = Forest, fontWeight = FontWeight.Bold)
                listOf("প্রোফাইল তৈরি", "প্রোফাইল খোঁজা ও ফিল্টার", "পছন্দের তালিকা").forEach {
                    Text("✓ $it", modifier = Modifier.padding(top = 8.dp))
                }
                Button(onClick = { onInfo("ফ্রি প্ল্যান নির্বাচিত। এটি ডেমো; অ্যাকাউন্ট তৈরি হয়নি।") }) {
                    Text("ফ্রি প্ল্যান")
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1E5C6))) {
            Column(Modifier.padding(16.dp)) {
                Text("✦ প্রিমিয়াম", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color(0xFF59431A))
                Text("আরও বেশি ম্যাচিং সুবিধা", color = Color(0xFF59431A))
                listOf("আরও বেশি আগ্রহ প্রকাশ", "উন্নত অনুসন্ধান", "যোগাযোগের অনুরোধ").forEach {
                    Text("✓ $it", modifier = Modifier.padding(top = 8.dp), color = Color(0xFF59431A))
                }
                Button(onClick = { onInfo("প্রিমিয়াম মূল্য ও পেমেন্ট এখনো যুক্ত হয়নি। কোনো টাকা নেওয়া হয়নি।") }) {
                    Text("প্রিমিয়াম সম্পর্কে জানুন")
                }
            }
        }
    }
}

@Composable
private fun ProfileForm(onPreview: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("পাত্র") }
    var country by remember { mutableStateOf("বাংলাদেশ") }
    var bio by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("আমার প্রোফাইল", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("এই ফর্মটি শুধু স্থানীয় প্রিভিউ দেখায়; তথ্য সার্ভারে জমা হয় না।", color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(value = age, onValueChange = { age = it.filter(Char::isDigit).take(3) }, label = { Text("বয়স (১৮+)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        FilterDropdown("আমি", role, listOf("পাত্র", "পাত্রী", "অভিভাবক"), Modifier.fillMaxWidth()) { role = it }
        FilterDropdown("দেশ", country, listOf("বাংলাদেশ", "সৌদি আরব", "ভারত", "অন্যান্য"), Modifier.fillMaxWidth()) { country = it }
        OutlinedTextField(value = bio, onValueChange = { bio = it.take(180) }, label = { Text("নিজের সম্পর্কে") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                val n = age.toIntOrNull()
                if (name.isBlank() || n == null || n < 18 || n > 100) {
                    onPreview("অনুগ্রহ করে নাম দিন এবং ১৮–১০০ বছরের মধ্যে সঠিক বয়স লিখুন।")
                } else {
                    onPreview("প্রোফাইল প্রিভিউ\nনাম: $name\nধরন: $role\nবয়স: $n\nদেশ: $country\nপরিচয়: ${bio.ifBlank { "দেওয়া হয়নি" }}\n\nএটি শুধু ডেমো; তথ্য সংরক্ষণ করা হয়নি।")
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("প্রিভিউ দেখুন") }
    }
}
